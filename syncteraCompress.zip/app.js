const express = require("express");
const bodyParser = require("body-parser");
const { PORT } = require("./config/config");
const customerRoutes = require("./routes/personalCustomer/personRoutes");
const disclosuerRoutes = require("./routes/disclouser/disclouserRoutes");
const verificationRoutes = require("./routes/verify/kyvVerification");
const businessesRoutes = require("./routes/Business/businessRoutes");

const app = express();

app.use(bodyParser.json());

app.use("/api/customers/", customerRoutes);
app.use("/api/businesses/", businessesRoutes);
app.use("/api/disclosures/", disclosuerRoutes);
app.use("/api/verifications/", verificationRoutes);

app.listen(PORT, (res) => {
  console.log(`Server started on port ${PORT}`);
});
